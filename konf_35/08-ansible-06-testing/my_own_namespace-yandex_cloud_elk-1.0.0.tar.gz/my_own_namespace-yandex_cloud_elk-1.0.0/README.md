# Ansible Collection - my_own_namespace.yandex_cloud_elk

This collection contains a module for creating a content file and a playbook for testing the module

Module: `my_own_module.py`

Using:

```
ansible-playbook playbook.yaml
```

With the default variable values, a file will be created at `/tml/test_file.txt` with `test content`

